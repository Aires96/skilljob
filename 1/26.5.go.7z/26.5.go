package main

import (
	"bufio"
	"bytes"
	"fmt"
	"os"
	"strings"
)

func main() {
	f1, err := os.Open("first.txt")
	if err != nil {
		fmt.Println("Error", err)
		os.Exit(1)
	}
	f2, err := os.Open("second.txt")
	if err != nil {
		fmt.Println("Error", err)
		os.Exit(1)
	}

	defer f1.Close()
	defer f2.Close()

	w1 := bytes.Buffer{}
	s1 := bufio.NewScanner(f1)
	for s1.Scan() {
		w1.WriteString(s1.Text())
	}
	fmt.Println(w1.String())

	w2 := bytes.Buffer{}
	s2 := bufio.NewScanner(f2)
	for s2.Scan() {
		w2.WriteString(s2.Text())
	}
	fmt.Println(w2.String())

	f1.WriteString("hello")
	f2.WriteString("World")

	strSlise := []string{f1.Name(), f2.Name()}
	result := strings.Join(strSlise, " ")
	fmt.Println(string(result))
}
